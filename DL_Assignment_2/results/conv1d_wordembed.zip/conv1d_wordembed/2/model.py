# Build the Model
model = Sequential()
model.add(layers.Embedding(max_words, 256, input_length=max_len))
model.add(layers.Conv1D(32, 5, activation='relu'))
model.add(layers.MaxPooling1D(5))
model.add(layers.Conv1D(32, 5, activation='relu'))
model.add(layers.GlobalMaxPooling1D())
model.add(layers.Dense(5))

model.summary()

# Train the Model
model.compile(optimizer=optimizers.RMSprop(lr=1e-3),
              loss='sparse_categorical_crossentropy',
              metrics=['acc'])
history = model.fit(X_train, y_train,
                    epochs=25,
                    batch_size=128,
                    validation_split=0.2)