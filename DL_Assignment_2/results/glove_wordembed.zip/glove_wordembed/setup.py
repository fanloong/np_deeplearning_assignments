# glove_dir = 'glove.6B'

# embeddings_index = {}
# f = open(os.path.join(glove_dir, 'glove.6B.50d.txt'), encoding="utf8")
# for line in f:
#     values = line.split()
#     word = values[0]
#     coefs = np.asarray(values[1:], dtype='float32')
#     embeddings_index[word] = coefs
# f.close()

# print('Found %s word vectors.' % len(embeddings_index))

# embedding_dim = xx

# embedding_matrix = np.zeros((max_words, embedding_dim))
# for word, i in word_index.items():
#     embedding_vector = embeddings_index.get(word)
#     if i < max_words:
#         if embedding_vector is not None:
#             # Words not found in embedding index will be all-zeros.
#             embedding_matrix[i] = embedding_vector